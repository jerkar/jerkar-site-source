Libraries found here are standard part of Jerkar. 
They are also included in the Jerkar fat jar called "org.jerkar.core-all.jar".
Jerkar user should not add anything here.

